Name: HARINI KUCHIBHOTLA - kuchi027
How to compile and run the program- 1. Extract the contents of the zip file to a directory on your computer.
				    2. Using terminal or command prompt, go the directory with the contents by using the cd command.
                                    3. Use the javac command to compile the java source file as: javac Game.java
  				    4. Next, you can run the program by using the java command followed by the name of the main class as: java Game
				    5. Input the move you want to make and press Enter key
Outside sources- no outside sources

I certify that the information contained in this README file is complete and accurate. I have both read and followed the course policies in the ‘Academic Integrity - Course Policy’ section of the course syllabus
Harini Kuchibhotla
